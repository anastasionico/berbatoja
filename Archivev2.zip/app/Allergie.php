<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Allergie extends Model
{
    protected $fillable = ['name'];
}
