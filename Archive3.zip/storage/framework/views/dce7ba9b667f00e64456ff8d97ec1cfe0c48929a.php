<aside>
    <div id="sidebar" class="nav-collapse ">
        <!-- sidebar menu start-->
        <ul class="sidebar-menu" id="nav-accordion">
            <li class="mt">
                <a class="active" href="/admin">
                    <i class="fa fa-dashboard"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            <li class="sub-menu">
                <a href="javascript:;">
                    <i class="fa fa-cutlery"></i>
                    <span>Ristorante</span>
                </a>
                <ul class="sub">
                    <li><a href="/admin/ristorante">Info</a></li>
                    <li><a href="/admin/ristorante_gallery">Gallery</a></li>
                    <li><a href="/admin/ristorante_piatti">Dishes</a></li>
                </ul>
            </li>
            <li class="sub-menu">
                <a href="/admin/allergie">
                    <i class="fa fa-flash"></i>
                    <span>Allergies</span>
                </a>
            </li>
            <li class="sub-menu">
                <a href="/admin/diete">
                    <i class="fa fa-sun-o"></i>
                    <span>Diets</span>
                </a>
            </li>






































































































        </ul>
        <!-- sidebar menu end-->
    </div>
</aside>
<?php /**PATH /Users/nicoanastasio/Documents/Nico/berbatoja/resources/views/admin/layout/aside.blade.php ENDPATH**/ ?>